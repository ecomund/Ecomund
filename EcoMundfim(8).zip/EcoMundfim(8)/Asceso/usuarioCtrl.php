<?php

$nome 	= $_POST['nome'];
$email 	= $_POST['email'];
$idade 	= $_POST['idade'];
$estado = $_POST['estado'];
$cidade = $_POST['cidade']; 

	if (empty($nome) || empty($email) || empty($idade ) || empty($estado) || empty($cidade)) {

	}else{
		
		$sql = "INSERT INTO `ecomund`.`site` (`NOME_COMPLETO`, `EMAIL`, `IDADE`, `ESTADO`, `CIDADE`) VALUES ('$nome', '$email', '$idade', '$estado', '$cidade');";
		
		$conn = new mysqli ("localhost","root","Aluno","ecomund"); 
		
		$conn->query($sql);
		
		$conn->close ();
		
	include 'usuarioRegistrado.php';
	}

?>