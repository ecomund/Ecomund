<?php




?>
<html>
		
		<style>
		
			body{
				background-image: linear-gradient(#38005b, #0066ad);
				font-family: sans-serif;
			}
				
			.Cadastro{
				background-image: linear-gradient(to right, #38005b, #0066ad);
				width: 90%;
				border-radius: 30px;
				padding: 15px;
				color: white;
				border: 0px;
				outline: 0;
				margin-bottom: 10px;
			}
			
			.Cadastro:hover{
				background-image: linear-gradient(to right, #0066ad, #38005b);
			}
			
			.confirm{
				float: left;
				width: 30px;
			}
			
			.Box{
				font-family: Arial ;
				margin-top: 10px;
			}
			
			.card-group{
				width: 40%;
				padding: 20px;
				outline: 0;
				margin-bottom: 10px;
				text-align: center;
				
			}
			
			.card-group > input{
				border-radius: 1px;
				outline: 0px;
				width: 220%;
				height: 40px;
				padding: 5px;
			}
			
			.card{
				margin: auto;
				margin-top: 40px;
				width: 25%;
				box-shadow: 4px 4px 10px #ccc;
				background-color: #ffffff;
				padding: 30px;
				border-radius: 5px;
				display: block;
				text-align: center;
			}
			
		</style>
		
		<head>
			<meta charset="UTF-8">
			<meta name="viewport" content="width=device=width, initial=scale=1.0">
			<meta http-equiv="X-UA-compatible" content="ie=edge">
		</head>
	<body>	
		<form method="POST" action="usuarioCtrl.php">
			<div class="card">	
				<label>Nome</label><br>
				<div class="card-group">
					<input type="name" name="nome" placeholder="Nome completo" required /><br>
				</div>
				<label>Email</label><br>
				<div class="card-group">
					<input type="email" name="email" placeholder="Insira seu email" required /><br>
				</div>
				<label>Idade</label><br>
				<div class="card-group">
					<input type="number_format" name="idade" required /><br>
				</div>
				<label>Estado</label><br>
				<div class="card-group">
					<input type="text" name="estado" required /><br>
			    </div>
				<label>Cidade</label><br>
				<div class="card-group">
					<input type="text" name="cidade" placeholder="informe sua cidade" required /><br>
			    </div>
				<div class="Cadastro">
					<button type="submit">Cadastrar</button></br>
				</div>
			</div>	
		</form>
	</body>



</html>