<?php
	//echo '<h1>Registro feito com sucesso</h1>';
	//method get puxa uma pagina
?>
<html>

	<style>
	
		body{
			font-family: Arial;
		}
		.card-group	{
			font-family: Arial;
			margin: auto;
			margin-top: 40px;
			width: 25%;
			box-shadow: 4px 4px 10px #ccc;
			padding: 30px;
			border-radius: 5px;
			display: block;
			
		}
	</style>
	
	<head>
			<meta charset="UTF-8">
			<meta name="viewport" content="width=device=width, initial=scale=1.0">
			<meta http-equiv="X-UA-compatible" content="ie=edge">
	</head>
	
	<body>
		<div class="card-group">
			<h1>Você foi Regitrado com sucesso</h1>
		</div>
	</body>	
</html>


