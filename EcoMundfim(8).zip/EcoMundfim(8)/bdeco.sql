create database ecomund;
use ecomund;

create table site(
	ID_USUARIO int not null AUTO_INCREMENT,
	NOME_COMPLETO varchar (60) NOT NULL,
	EMAIL VARCHAR (80) NOT NULL,
	IDADE NUMERIC (4) NOT NULL,
	ESTADO ENUM ('AC','AL','AP','AM','BA','CE','ES','GO','MA','MT','MS','MG','PA','PB','PR','PE','PI','RJ','RN','RS','RO','RR','SC','SP','SE','TO') NOT NULL,
	CIDADE VARCHAR (25) NOT NULL,
	CONSTRAINT PK_site PRIMARY KEY (ID_USUARIO)
)